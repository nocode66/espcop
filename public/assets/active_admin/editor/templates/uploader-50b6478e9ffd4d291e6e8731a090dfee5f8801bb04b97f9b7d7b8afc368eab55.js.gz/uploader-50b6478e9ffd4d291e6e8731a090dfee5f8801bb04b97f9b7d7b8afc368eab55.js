(function() { this.JST || (this.JST = {}); this.JST["active_admin/editor/templates/uploader"] = function(obj){var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('<div class="upload">\n  or\n  <input type="file" />\n  <img src="',  spinner ,'" class="spinner"></img>\n</div>\n<div style="clear: both;"></div>\n');}return __p.join('');};
}).call(this);
