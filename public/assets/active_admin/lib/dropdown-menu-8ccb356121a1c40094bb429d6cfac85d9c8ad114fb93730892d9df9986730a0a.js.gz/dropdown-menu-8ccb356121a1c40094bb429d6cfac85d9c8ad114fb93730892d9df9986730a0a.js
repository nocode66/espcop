(function() {
  ActiveAdmin.DropdownMenu = (function() {
    function DropdownMenu(options, element) {
      var defaults;
      this.options = options;
      this.element = element;
      this.$element = $(this.element);
      defaults = {
        fadeInDuration: 20,
        fadeOutDuration: 100,
        onClickActionItemCallback: null
      };
      this.options = $.extend(defaults, this.options);
      this.isOpen = false;
      this.$menuButton = this.$element.find('.dropdown_menu_button');
      this.$menuList = this.$element.find('.dropdown_menu_list_wrapper');
      this._buildMenuList();
      this._bind();
    }

    DropdownMenu.prototype.open = function() {
      this.isOpen = true;
      this.$menuList.fadeIn(this.options.fadeInDuration);
      this._position();
      return this;
    };

    DropdownMenu.prototype.close = function() {
      this.isOpen = false;
      this.$menuList.fadeOut(this.options.fadeOutDuration);
      return this;
    };

    DropdownMenu.prototype.destroy = function() {
      this.$element.unbind();
      this.$element = null;
      return this;
    };

    DropdownMenu.prototype.isDisabled = function() {
      return this.$menuButton.hasClass('disabled');
    };

    DropdownMenu.prototype.disable = function() {
      return this.$menuButton.addClass('disabled');
    };

    DropdownMenu.prototype.enable = function() {
      return this.$menuButton.removeClass('disabled');
    };

    DropdownMenu.prototype.option = function(key, value) {
      if ($.isPlainObject(key)) {
        return this.options = $.extend(true, this.options, key);
      } else if (key != null) {
        return this.options[key];
      } else {
        return this.options[key] = value;
      }
    };

    DropdownMenu.prototype._buildMenuList = function() {
      this.$nipple = $('<div class="dropdown_menu_nipple"></div>');
      this.$menuList.prepend(this.$nipple);
      return this.$menuList.hide();
    };

    DropdownMenu.prototype._bind = function() {
      $('body').click((function(_this) {
        return function() {
          if (_this.isOpen) {
            return _this.close();
          }
        };
      })(this));
      return this.$menuButton.click((function(_this) {
        return function() {
          if (!_this.isDisabled()) {
            if (_this.isOpen) {
              _this.close();
            } else {
              _this.open();
            }
          }
          return false;
        };
      })(this));
    };

    DropdownMenu.prototype._position = function() {
      var button_center, button_left, button_right, centered_menu_left, centered_menu_right, menu_center, nipple_center, window_right;
      this.$menuList.css('top', this.$menuButton.position().top + this.$menuButton.outerHeight() + 10);
      button_left = this.$menuButton.position().left;
      button_center = this.$menuButton.outerWidth() / 2;
      button_right = button_left + button_center * 2;
      menu_center = this.$menuList.outerWidth() / 2;
      nipple_center = this.$nipple.outerWidth() / 2;
      window_right = $(window).width();
      centered_menu_left = button_left + button_center - menu_center;
      centered_menu_right = button_left + button_center + menu_center;
      if (centered_menu_left < 0) {
        this.$menuList.css('left', button_left);
        return this.$nipple.css('left', button_center - nipple_center);
      } else if (centered_menu_right > window_right) {
        this.$menuList.css('right', window_right - button_right);
        return this.$nipple.css('right', button_center - nipple_center);
      } else {
        this.$menuList.css('left', centered_menu_left);
        return this.$nipple.css('left', menu_center - nipple_center);
      }
    };

    return DropdownMenu;

  })();

  $.widget.bridge('aaDropdownMenu', ActiveAdmin.DropdownMenu);

  $(document).on('ready page:load turbolinks:load', function() {
    return $('.dropdown_menu').aaDropdownMenu();
  });

}).call(this);
