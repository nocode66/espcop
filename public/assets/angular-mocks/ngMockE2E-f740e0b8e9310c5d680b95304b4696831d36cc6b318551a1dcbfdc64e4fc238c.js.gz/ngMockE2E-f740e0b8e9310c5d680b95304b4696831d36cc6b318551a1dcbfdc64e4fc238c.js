require('./angular-mocks');
module.exports = 'ngMockE2E';
