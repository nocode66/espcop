window.tinyMCEPreInit = window.tinyMCEPreInit || {
  base:   '/assets/tinymce',
  query:  '3.5.8.3',
  suffix: ''
};
