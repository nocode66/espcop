tinyMCE.addI18n('es.uploadimage', {
  desc: 'Insertar una imagen desde su computadora'
});
