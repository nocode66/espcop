tinyMCE.addI18n('en', {
  'Insert an image from your computer': 'Insert an image from your computer',
  'Insert image': 'Insert image',
  'Choose an image': "Choose an image",
  'You must choose a file': "You must choose a file",
  'Got a bad response from the server': "Got a bad response from the server",
  "Didn't get a response from the server": "Didn't get a response from the server",
  'Insert': "Insert",
  'Cancel': "Cancel",
  'Image description': "Image description",
});
