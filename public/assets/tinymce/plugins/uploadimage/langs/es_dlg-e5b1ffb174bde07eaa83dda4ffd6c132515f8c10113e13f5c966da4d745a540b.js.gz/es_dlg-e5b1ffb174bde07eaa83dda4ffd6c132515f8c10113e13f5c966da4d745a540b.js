tinyMCE.addI18n('es.uploadimage_dlg', {
  title: 'Insertar una imagen',
  header: "Insertar una imagen",
  input:  "Elija una imagen",
  uploading: "Subiendo…",
  blank_input: "Debe elegir un archivo",
  bad_response: "Mala respuesta del servidor",
  blank_response: "No se recibió respuesta del servidor",
  insert: "Insertar",
  cancel: "Cancelar",
  alt_text: "Descripción de la imagen"
});
