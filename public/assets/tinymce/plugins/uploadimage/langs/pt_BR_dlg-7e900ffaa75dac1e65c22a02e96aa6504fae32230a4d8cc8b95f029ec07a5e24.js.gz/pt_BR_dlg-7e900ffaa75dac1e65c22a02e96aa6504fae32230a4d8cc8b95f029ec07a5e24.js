tinyMCE.addI18n('pt_BR.uploadimage_dlg', {
  title: 'Inserir imagem',
  header: "Inserir imagem",
  input:  "Escolher uma imagem",
  uploading: "Enviando...",
  blank_input: "É necessário selecionar um diretório",
  bad_response: "Resposta inesperada do servidor",
  blank_response: "Servidor não está respondendo",
  insert: "Inserir",
  cancel: "Cancelar",
  alt_text: "Image description"
});
