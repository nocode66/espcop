tinyMCE.addI18n('nb.uploadimage_dlg', {
  title: 'Sett inn bilde',
  header: "Sett inn bilde",
  input:  "Velg et bilde",
  uploading: "Laster opp…",
  blank_input: "M\u00e5 velge en fil",
  bad_response: "Fikk et ugyldig svar fra serveren",
  blank_response: "Fikk ikke svar fra serveren",
  insert: "Sett inn",
  cancel: "Avbryt",
  alt_text: "Alternativ tekst for bilde"
});
