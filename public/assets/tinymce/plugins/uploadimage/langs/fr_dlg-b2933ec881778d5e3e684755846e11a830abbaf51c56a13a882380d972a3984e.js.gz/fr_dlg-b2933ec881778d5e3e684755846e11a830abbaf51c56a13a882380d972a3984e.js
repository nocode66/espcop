tinyMCE.addI18n('fr.uploadimage_dlg', {
  title: "Insérer une image",
  header: "Insérer une image",
  input: "Choisissez une image",
  uploading: "Transfert en cours ...",
  blank_input: "Vous devez sélectionner un fichier",
  bad_response: "Le serveur a envoyé une réponse erronée",
  blank_response: "Le serveur n'a pas renvoyé de réponse",
  insert: "Insérer",
  cancel: "Annuler",
  alt_text: "Description de l'image"
});
