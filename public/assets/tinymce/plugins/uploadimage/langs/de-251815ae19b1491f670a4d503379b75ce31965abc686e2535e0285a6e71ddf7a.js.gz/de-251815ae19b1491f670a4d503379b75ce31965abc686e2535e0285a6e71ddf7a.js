tinyMCE.addI18n('de.uploadimage', {
  desc: 'Bild vom Computer einfügen'
});
