tinyMCE.addI18n('fr.uploadimage', {
  desc: "Envoyer une image de votre ordinateur"
});
