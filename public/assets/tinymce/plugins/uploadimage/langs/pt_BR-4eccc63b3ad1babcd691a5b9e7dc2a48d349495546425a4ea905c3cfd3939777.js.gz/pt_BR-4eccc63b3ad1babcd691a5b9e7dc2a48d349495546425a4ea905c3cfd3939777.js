tinyMCE.addI18n('pt_BR', {
  'Insert an image from your computer': 'Inserir uma imagem do computador',
  'Insert image': 'Inserir imagem',
  'Choose an image': "Escolher uma imagem",
  'You must choose a file': "É necessário selecionar um diretório",
  'Got a bad response from the server': "Resposta inesperada do servidor",
  "Didn't get a response from the server": "Servidor não está respondendo",
  'Insert': "Inserir",
  'Cancel': "Cancelar",
  'Image description': "Descrição da imagem",
});
