tinyMCE.addI18n('de.uploadimage_dlg', {
  title: 'Bild einfügen',
  header: "Bild einfügen",
  input:  "Bild auswählen",
  uploading: "Wird geladen...",
  blank_input: "Datei auswählen",
  bad_response: "Ungültige Antwort vom Server",
  blank_response: "Server antwortet nicht",
  insert: "Einfügen",
  cancel: "Abbrechen",
  alt_text: "Bildbeschreibung"
});
