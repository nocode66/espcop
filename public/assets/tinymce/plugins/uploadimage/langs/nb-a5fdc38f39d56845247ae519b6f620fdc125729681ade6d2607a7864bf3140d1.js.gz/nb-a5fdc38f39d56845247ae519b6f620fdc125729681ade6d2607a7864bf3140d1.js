tinyMCE.addI18n('nb.uploadimage', {
  desc: 'Sett inn et bilde fra datamaskinen'
});
