tinyMCE.addI18n('zh-cn.uploadimage_dlg', {
  title: "\u63d2\u5165\u56fe\u7247",
  header: "\u63d2\u5165\u56fe\u7247",
  input:  "\u9009\u62e9\u56fe\u7247",
  uploading: "\u4e0a\u4f20\u4e2d\u2026",
  blank_input: "\u5fc5\u987b\u9009\u62e9\u6587\u4ef6",
  bad_response: "\u670d\u52a1\u5668\u8fd4\u56de\u9519\u8bef",
  blank_response: "\u670d\u52a1\u5668\u6ca1\u6709\u54cd\u5e94",
  insert: "\u63d2\u5165",
  cancel: "\u53d6\u6d88",
  alt_text: "\u56fe\u7247\u63cf\u8ff0"
});
