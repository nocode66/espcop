tinyMCE.addI18n('ru.uploadimage_dlg', {
  title: 'Вставить изображение',
  header: "Вставить изображение",
  input:  "Выберите изображение",
  uploading: "Загрузка…",
  blank_input: "Необходимо выбрать файл",
  bad_response: "Получен некорректный ответ с сервера",
  blank_response: "Не получен ответ с сервера",
  insert: "Вставить",
  cancel: "Отмена",
  alt_text: "Информация об изображении"
});
