tinyMCE.addI18n('pt.uploadimage_dlg', {
  title: 'Inserir imagem',
  header: "Inserir imagem",
  input:  "Escolher uma imagem",
  uploading: "A enviar…",
  blank_input: "É necessário seleccionar um ficheiro",
  bad_response: "Resposta inesperada do servidor",
  blank_response: "Não foi obtida uma resposta do servidor",
  insert: "Inserir",
  cancel: "Cancelar",
  alt_text: "Image description"
});
