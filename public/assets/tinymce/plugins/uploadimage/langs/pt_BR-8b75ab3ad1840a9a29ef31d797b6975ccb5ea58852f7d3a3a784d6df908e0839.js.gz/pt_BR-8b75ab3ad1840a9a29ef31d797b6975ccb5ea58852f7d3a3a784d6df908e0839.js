tinyMCE.addI18n('pt_BR.uploadimage', {
  desc: 'Inserir uma imagem do computador'
});
