tinyMCE.addI18n('pl', {
  'Insert an image from your computer': 'Wstaw zdjęcie z komputera',
  'Insert image': 'Wstaw zdjęcie',
  'Choose an image': "Wybierz zdjęcie",
  'You must choose a file': "Musisz wybrać plik",
  'Got a bad response from the server': "Niepoprawna odpowiedź serwera",
  "Didn't get a response from the server": "Brak odpowiedzi z serwera",
  'Insert': "Wstaw",
  'Cancel': "Anuluj",
  'Image description': "Opis grafiki",
});
