tinyMCE.addI18n('ru.uploadimage', {
  desc: 'Вставить изображение с вашего компьютера'
});
