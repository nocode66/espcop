tinyMCE.addI18n('zh-cn.uploadimage', {
  desc: "\u4e0a\u4f20\u56fe\u7247"
});
